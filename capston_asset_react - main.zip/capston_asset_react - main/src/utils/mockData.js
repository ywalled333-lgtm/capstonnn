// Mock Users
export const mockUsers = [
  {
    id: 1,
    name: 'Ahmed Hassan',
    email: 'user@eva.com',
    password: 'password123',
    username: 'ahmed.hassan',
    role: 'user',
    avatar: '👨‍💼',
    department: 'Marketing'
  },
  {
    id: 2,
    name: 'Fatima Manager',
    email: 'manager@eva.com',
    password: 'password123',
    username: 'fatima.mgr',
    role: 'asset_manager',
    avatar: '👩‍💼',
    department: 'Operations'
  },
  {
    id: 3,
    name: 'Admin User',
    email: 'admin@eva.com',
    password: 'password123',
    username: 'admin',
    role: 'admin',
    avatar: '👨‍🔧',
    department: 'IT'
  }
]

// Mock Assets
export const mockAssets = [
  {
    id: 1,
    name: 'Dell XPS 15 Laptop',
    category: 'Electronics',
    type: 'Laptop',
    price: 1500,
    date: '2024-01-15',
    location: 'Office Floor 3',
    status: 'in_use',
    color: 'Silver',
    image: '💻',
    assignedToId: 1,
    assignedToName: 'Ahmed Hassan'
  },
  {
    id: 2,
    name: 'Canon EOS R5 Camera',
    category: 'Photography',
    type: 'Camera',
    price: 3800,
    date: '2024-01-10',
    location: 'Photo Studio',
    status: 'available',
    color: 'Black',
    image: '📷',
    assignedToId: null,
    assignedToName: null
  },
  {
    id: 3,
    name: 'iMac 27"',
    category: 'Electronics',
    type: 'Desktop',
    price: 2200,
    date: '2024-01-20',
    location: 'Office Floor 2',
    status: 'in_use',
    color: 'Silver',
    image: '🖥️',
    assignedToId: 2,
    assignedToName: 'Fatima Manager'
  },
  {
    id: 4,
    name: 'Sony A1 Camera',
    category: 'Photography',
    type: 'Camera',
    price: 6500,
    date: '2024-02-01',
    location: 'Video Studio',
    status: 'maintenance',
    color: 'Black',
    image: '📷',
    assignedToId: null,
    assignedToName: null
  },
  {
    id: 5,
    name: 'Apple iPhone 15 Pro',
    category: 'Mobile',
    type: 'Smartphone',
    price: 1200,
    date: '2024-02-05',
    location: 'Office Reception',
    status: 'available',
    color: 'Gold',
    image: '📱',
    assignedToId: null,
    assignedToName: null
  },
  {
    id: 6,
    name: 'iPad Air',
    category: 'Mobile',
    type: 'Tablet',
    price: 800,
    date: '2024-02-10',
    location: 'Conference Room',
    status: 'in_use',
    color: 'Space Gray',
    image: '📱',
    assignedToId: 1,
    assignedToName: 'Ahmed Hassan'
  },
  {
    id: 7,
    name: 'Office Desk',
    category: 'Furniture',
    type: 'Desk',
    price: 500,
    date: '2024-01-30',
    location: 'Office Floor 1',
    status: 'in_use',
    color: 'White',
    image: '🪑',
    assignedToId: 3,
    assignedToName: 'Admin User'
  },
  {
    id: 8,
    name: 'Filing Cabinet',
    category: 'Furniture',
    type: 'Cabinet',
    price: 300,
    date: '2024-02-15',
    location: 'Storage Room',
    status: 'retired',
    color: 'Gray',
    image: '📁',
    assignedToId: null,
    assignedToName: null
  },
  {
    id: 9,
    name: 'Logitech MX Master',
    category: 'Accessories',
    type: 'Mouse',
    price: 100,
    date: '2024-02-20',
    location: 'Office Floor 1',
    status: 'available',
    color: 'Space Gray',
    image: '🖱️',
    assignedToId: null,
    assignedToName: null
  },
  {
    id: 10,
    name: 'Mechanical Keyboard',
    category: 'Accessories',
    type: 'Keyboard',
    price: 150,
    date: '2024-02-22',
    location: 'Office Floor 1',
    status: 'in_use',
    color: 'Silver',
    image: '⌨️',
    assignedToId: 1,
    assignedToName: 'Ahmed Hassan'
  }
]

// Mock Products
export const mockProducts = [
  {
    id: 1,
    name: 'Lip Tint Collection',
    category: 'Lips',
    type: 'Liquid',
    price: 25,
    count: 150,
    color: 'Rose Pink',
    image: '💄'
  },
  {
    id: 2,
    name: 'Foundation SPF 30',
    category: 'Face',
    type: 'Liquid',
    price: 35,
    count: 200,
    color: 'Beige',
    image: '💄'
  },
  {
    id: 3,
    name: 'Eye Makeup Palette',
    category: 'Eyes',
    type: 'Powder',
    price: 40,
    count: 100,
    color: 'Multi',
    image: '👁️'
  },
  {
    id: 4,
    name: 'Mascara Waterproof',
    category: 'Eyes',
    type: 'Liquid',
    price: 22,
    count: 180,
    color: 'Black',
    image: '💄'
  },
  {
    id: 5,
    name: 'Blush Powder',
    category: 'Face',
    type: 'Powder',
    price: 28,
    count: 120,
    color: 'Coral',
    image: '🎨'
  }
]

// Mock Reports
export const mockReports = [
  {
    id: 1,
    title: 'Camera Equipment Maintenance',
    description: 'Scheduled maintenance for Canon and Sony cameras',
    authorId: 2,
    authorName: 'Fatima Manager',
    assetId: 4,
    assetName: 'Sony A1 Camera',
    time: '2024-02-25T10:30:00',
    status: 'pending',
    userId: 2
  },
  {
    id: 2,
    title: 'Asset Damage Report',
    description: 'Keyboard has a few broken keys',
    authorId: 1,
    authorName: 'Ahmed Hassan',
    assetId: 10,
    assetName: 'Mechanical Keyboard',
    time: '2024-02-24T14:20:00',
    status: 'in_progress',
    userId: 1
  },
  {
    id: 3,
    title: 'Inventory Check Completed',
    description: 'All assets in office floor 1 have been verified',
    authorId: 2,
    authorName: 'Fatima Manager',
    assetId: null,
    assetName: null,
    time: '2024-02-23T09:00:00',
    status: 'completed',
    userId: 2
  },
  {
    id: 4,
    title: 'New Equipment Arrival',
    description: 'iPad Air has been received and set up',
    authorId: 2,
    authorName: 'Fatima Manager',
    assetId: 6,
    assetName: 'iPad Air',
    time: '2024-02-20T11:45:00',
    status: 'completed',
    userId: 2
  },
  {
    id: 5,
    title: 'Software License Renewal',
    description: 'Need to renew licenses for design software',
    authorId: 3,
    authorName: 'Admin User',
    assetId: 1,
    assetName: 'Dell XPS 15 Laptop',
    time: '2024-02-18T15:30:00',
    status: 'pending',
    userId: 3
  },
  {
    id: 6,
    title: 'Asset Transfer Request',
    description: 'Laptop transferred from user 1 to user 2',
    authorId: 2,
    authorName: 'Fatima Manager',
    assetId: 1,
    assetName: 'Dell XPS 15 Laptop',
    time: '2024-02-15T13:15:00',
    status: 'completed',
    userId: 1
  },
  {
    id: 7,
    title: 'Furniture Deprecation Notice',
    description: 'Filing cabinet to be removed from inventory',
    authorId: 3,
    authorName: 'Admin User',
    assetId: 8,
    assetName: 'Filing Cabinet',
    time: '2024-02-10T16:00:00',
    status: 'pending',
    userId: 3
  },
  {
    id: 8,
    title: 'Accessory Stock Low',
    description: 'Need to order more wireless mice',
    authorId: 2,
    authorName: 'Fatima Manager',
    assetId: 9,
    assetName: 'Logitech MX Master',
    time: '2024-02-08T10:20:00',
    status: 'completed',
    userId: 2
  }
]

// Mock Tasks
export const mockTasks = [
  {
    id: 1,
    title: 'Complete Asset Inventory',
    description: 'Review and verify all assets in the database',
    assignedTo: 'Fatima Manager',
    status: 'in_progress',
    dueDate: '2024-03-01',
    priority: 'high'
  },
  {
    id: 2,
    title: 'Update Camera Equipment',
    description: 'Upgrade photography equipment for studio',
    assignedTo: 'Ahmed Hassan',
    status: 'pending',
    dueDate: '2024-03-05',
    priority: 'medium'
  },
  {
    id: 3,
    title: 'Review User Reports',
    description: 'Check and process pending user reports',
    assignedTo: 'Admin User',
    status: 'pending',
    dueDate: '2024-03-02',
    priority: 'high'
  },
  {
    id: 4,
    title: 'Organize Storage Room',
    description: 'Arrange and catalog items in storage',
    assignedTo: 'Ahmed Hassan',
    status: 'completed',
    dueDate: '2024-02-28',
    priority: 'low'
  },
  {
    id: 5,
    title: 'Backup Database',
    description: 'Create backup of all system data',
    assignedTo: 'Admin User',
    status: 'in_progress',
    dueDate: '2024-03-01',
    priority: 'high'
  },
  {
    id: 6,
    title: 'Client Presentation Setup',
    description: 'Prepare equipment for client meeting',
    assignedTo: 'Fatima Manager',
    status: 'pending',
    dueDate: '2024-02-28',
    priority: 'medium'
  }
]

// Mock Notifications
export const mockNotifications = [
  {
    id: 1,
    userId: 1,
    message: 'Your report has been reviewed',
    isRead: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    type: 'info'
  },
  {
    id: 2,
    userId: 1,
    message: 'New asset assigned to you: iPad Air',
    isRead: false,
    createdAt: new Date(Date.now() - 7200000).toISOString(),
    type: 'success'
  },
  {
    id: 3,
    userId: 2,
    message: 'Camera maintenance is due',
    isRead: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    type: 'warning'
  }
]

// Helper function to initialize localStorage data
export const initializeMockData = () => {
  if (!localStorage.getItem('assets')) {
    localStorage.setItem('assets', JSON.stringify(mockAssets))
  }
  if (!localStorage.getItem('products')) {
    localStorage.setItem('products', JSON.stringify(mockProducts))
  }
  if (!localStorage.getItem('reports')) {
    localStorage.setItem('reports', JSON.stringify(mockReports))
  }
  if (!localStorage.getItem('tasks')) {
    localStorage.setItem('tasks', JSON.stringify(mockTasks))
  }
  if (!localStorage.getItem('notifications')) {
    localStorage.setItem('notifications', JSON.stringify(mockNotifications))
  }
  if (!localStorage.getItem('employees')) {
    localStorage.setItem('employees', JSON.stringify(mockUsers))
  }
}

// Helper functions for data management
export const getAssetsFromStorage = () => {
  return JSON.parse(localStorage.getItem('assets') || '[]')
}

export const getProductsFromStorage = () => {
  return JSON.parse(localStorage.getItem('products') || '[]')
}

export const getReportsFromStorage = () => {
  return JSON.parse(localStorage.getItem('reports') || '[]')
}

export const getTasksFromStorage = () => {
  return JSON.parse(localStorage.getItem('tasks') || '[]')
}

export const getNotificationsFromStorage = () => {
  return JSON.parse(localStorage.getItem('notifications') || '[]')
}

export const getEmployeesFromStorage = () => {
  return JSON.parse(localStorage.getItem('employees') || '[]')
}

// Save functions
export const saveAssets = (assets) => {
  localStorage.setItem('assets', JSON.stringify(assets))
}

export const saveProducts = (products) => {
  localStorage.setItem('products', JSON.stringify(products))
}

export const saveReports = (reports) => {
  localStorage.setItem('reports', JSON.stringify(reports))
}

export const saveTasks = (tasks) => {
  localStorage.setItem('tasks', JSON.stringify(tasks))
}

export const saveNotifications = (notifications) => {
  localStorage.setItem('notifications', JSON.stringify(notifications))
}

export const saveEmployees = (employees) => {
  localStorage.setItem('employees', JSON.stringify(employees))
}
