import { useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import { ProtectedRoute } from './components/ProtectedRoute'
import { initializeMockData } from './utils/mockData'

// Pages
import { Login } from './features/auth/Login'
import { Dashboard } from './features/dashboard/Dashboard'
import { Assets } from './features/assets/Assets'
import { AddEditAsset } from './features/assets/AddEditAsset'
import { Employees, AddEditEmployee } from './features/employees/Employees'
import { Reports } from './features/reports/Reports'
import { AddReport } from './features/reports/AddReport'
import { Inventory } from './features/inventory/Inventory'
import { AddEditProduct } from './features/inventory/AddEditProduct'
import { Profile } from './features/profile/Profile'
import { Notifications } from './features/notifications/Notifications'
import { Chat } from './features/chat/Chat'

function App() {
  useEffect(() => {
    // Initialize mock data on app load
    initializeMockData()
  }, [])

  return (
    <Router>
      <AuthProvider>
        <ThemeProvider>
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<Login />} />

            {/* Protected Routes */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />

            {/* Assets Routes */}
            <Route
              path="/assets"
              element={
                <ProtectedRoute>
                  <Assets />
                </ProtectedRoute>
              }
            />
            <Route
              path="/assets/add"
              element={
                <ProtectedRoute>
                  <AddEditAsset />
                </ProtectedRoute>
              }
            />
            <Route
              path="/assets/edit/:id"
              element={
                <ProtectedRoute>
                  <AddEditAsset />
                </ProtectedRoute>
              }
            />

            {/* Employees Routes */}
            <Route
              path="/employees"
              element={
                <ProtectedRoute>
                  <Employees />
                </ProtectedRoute>
              }
            />
            <Route
              path="/employees/add"
              element={
                <ProtectedRoute>
                  <AddEditEmployee />
                </ProtectedRoute>
              }
            />
            <Route
              path="/employees/edit/:id"
              element={
                <ProtectedRoute>
                  <AddEditEmployee />
                </ProtectedRoute>
              }
            />

            {/* Reports Routes */}
            <Route
              path="/reports"
              element={
                <ProtectedRoute>
                  <Reports />
                </ProtectedRoute>
              }
            />
            <Route
              path="/reports/add"
              element={
                <ProtectedRoute>
                  <AddReport />
                </ProtectedRoute>
              }
            />

            {/* Inventory Routes */}
            <Route
              path="/inventory"
              element={
                <ProtectedRoute>
                  <Inventory />
                </ProtectedRoute>
              }
            />
            <Route
              path="/inventory/add"
              element={
                <ProtectedRoute>
                  <AddEditProduct />
                </ProtectedRoute>
              }
            />
            <Route
              path="/inventory/edit/:id"
              element={
                <ProtectedRoute>
                  <AddEditProduct />
                </ProtectedRoute>
              }
            />

            {/* Other Routes */}
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              }
            />
            <Route
              path="/notifications"
              element={
                <ProtectedRoute>
                  <Notifications />
                </ProtectedRoute>
              }
            />
            <Route
              path="/chat"
              element={
                <ProtectedRoute>
                  <Chat />
                </ProtectedRoute>
              }
            />

            {/* Catch all */}
            <Route path="/" element={<Navigate to="/dashboard" />} />
            <Route path="*" element={<Navigate to="/dashboard" />} />
          </Routes>
        </ThemeProvider>
      </AuthProvider>
    </Router>
  )
}

export default App
