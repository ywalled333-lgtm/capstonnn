import { useState, useParams } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Layout } from '../../components/layout/Layout'
import { Card, Button, Input } from '../../components/common'
import { getProductsFromStorage, saveProducts } from '../../utils/mockData'

export const AddEditProduct = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const { t } = useTranslation()
  const [formData, setFormData] = useState({
    name: '',
    category: 'Lips',
    type: 'Liquid',
    price: '',
    count: '',
    color: '',
    image: '💄',
  })

  const categories = ['Lips', 'Face', 'Eyes', 'Skincare', 'Other']
  const types = ['Liquid', 'Powder', 'Cream', 'Solid']

  const handleSubmit = (e) => {
    e.preventDefault()
    const products = getProductsFromStorage()
    
    if (id) {
      const updated = products.map(p =>
        p.id === parseInt(id) ? { ...p, ...formData, price: parseInt(formData.price), count: parseInt(formData.count) } : p
      )
      saveProducts(updated)
    } else {
      const newProduct = {
        ...formData,
        id: Math.max(...products.map(p => p.id), 0) + 1,
        price: parseInt(formData.price),
        count: parseInt(formData.count),
      }
      saveProducts([...products, newProduct])
    }

    navigate('/inventory')
  }

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-8">
          {id ? t('inventory.editProduct') : t('inventory.addProduct')}
        </h1>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label={t('inventory.productName')}
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('inventory.category')}
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('inventory.type')}
                </label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                >
                  {types.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('inventory.price')}
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
                required
              />
              <Input
                label={t('inventory.count')}
                type="number"
                value={formData.count}
                onChange={(e) => setFormData({...formData, count: e.target.value})}
                required
              />
            </div>

            <Input
              label={t('inventory.color')}
              value={formData.color}
              onChange={(e) => setFormData({...formData, color: e.target.value})}
            />

            <div className="flex gap-3 pt-6">
              <Button type="submit" className="flex-1">
                {id ? 'Update Product' : 'Create Product'}
              </Button>
              <Button
                type="button"
                variant="secondary"
                className="flex-1"
                onClick={() => navigate('/inventory')}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </Layout>
  )
}
