import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { useTranslation } from 'react-i18next'
import { Layout } from '../../components/layout/Layout'
import { Card, Button } from '../../components/common'
import { Send, Smile } from 'lucide-react'

const demoConversations = [
  {
    id: 1,
    name: 'Ahmed Hassan',
    avatar: '👨‍💼',
    lastMessage: 'Thanks for the update!',
    time: '2 minutes ago',
    unread: 2,
    messages: [
      { id: 1, sender: 'Ahmed Hassan', text: 'Hi there! How are you?', time: '10:30 AM' },
      { id: 2, sender: 'You', text: 'I am good, how about you?', time: '10:32 AM' },
      { id: 3, sender: 'Ahmed Hassan', text: 'Great! Got the asset details', time: '10:35 AM' },
      { id: 4, sender: 'Ahmed Hassan', text: 'Thanks for the update!', time: '10:40 AM' },
    ]
  },
  {
    id: 2,
    name: 'Fatima Manager',
    avatar: '👩‍💼',
    lastMessage: 'See you in the meeting',
    time: '1 hour ago',
    unread: 0,
    messages: [
      { id: 1, sender: 'Fatima Manager', text: 'Did you check the reports?', time: '09:15 AM' },
      { id: 2, sender: 'You', text: 'Yes, they look good', time: '09:20 AM' },
      { id: 3, sender: 'Fatima Manager', text: 'See you in the meeting', time: '09:45 AM' },
    ]
  }
]

export const Chat = () => {
  const { user } = useAuth()
  const { t } = useTranslation()
  const [selectedChat, setSelectedChat] = useState(demoConversations[0])
  const [message, setMessage] = useState('')
  const [messages, setMessages] = useState(selectedChat.messages)

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        id: messages.length + 1,
        sender: 'You',
        text: message,
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      }
      setMessages([...messages, newMessage])
      setMessage('')
    }
  }

  const handleSelectChat = (chat) => {
    setSelectedChat(chat)
    setMessages(chat.messages)
  }

  return (
    <Layout>
      <div className="p-6 h-[calc(100vh-100px)] flex gap-6 max-w-7xl mx-auto">
        {/* Conversations List */}
        <div className="w-80 hidden lg:block">
          <Card className="h-full flex flex-col p-0">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">
                {t('sidebar.chat')}
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto">
              {demoConversations.map(chat => (
                <button
                  key={chat.id}
                  onClick={() => handleSelectChat(chat)}
                  className={`w-full p-4 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-left ${
                    selectedChat.id === chat.id ? 'bg-primary-50 dark:bg-primary-900/20' : ''
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-3xl">{chat.avatar}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 dark:text-gray-100">
                        {chat.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                        {chat.lastMessage}
                      </p>
                    </div>
                    {chat.unread > 0 && (
                      <span className="bg-primary-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {chat.unread}
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col gap-6">
          {/* Header */}
          <Card className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">{selectedChat.avatar}</span>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                  {selectedChat.name}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Active now</p>
              </div>
            </div>
          </Card>

          {/* Messages */}
          <Card className="flex-1 flex flex-col overflow-hidden p-0">
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === 'You' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                      msg.sender === 'You'
                        ? 'bg-primary-600 text-white'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
                    }`}
                  >
                    <p>{msg.text}</p>
                    <p className={`text-xs mt-1 ${
                      msg.sender === 'You' ? 'text-primary-100' : 'text-gray-500 dark:text-gray-400'
                    }`}>
                      {msg.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                />
                <Button
                  onClick={handleSendMessage}
                  className="flex items-center space-x-2"
                >
                  <Send size={18} />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  )
}
