import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Layout } from '../../components/layout/Layout'
import { Card, Button, Input } from '../../components/common'
import { getEmployeesFromStorage, saveEmployees, initializeMockData } from '../../utils/mockData'
import { useAuth } from '../../context/AuthContext'
import { Plus, Trash2, Edit } from 'lucide-react'

export const Employees = () => {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { t } = useTranslation()
  const [employees, setEmployees] = useState([])
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    // load employees - always exclude the current logged-in user
    const allEmployees = getEmployeesFromStorage()
    if (user?.role === 'admin') {
      setEmployees(allEmployees.filter(e => e.id !== user?.id))
    } else {
      setEmployees(allEmployees.filter(e => e.role !== 'admin' && e.id !== user?.id))
    }
  }, [user])

  // Initialize mock data if not present
  useEffect(() => {
    const employees = getEmployeesFromStorage();
    if (employees.length === 0) {
      console.log('No employees found in localStorage. Initializing mock data.');
      initializeMockData();
    }
  }, []);

  // deletion - only admins can delete
  const handleDelete = (id) => {
    const updated = employees.filter(e => e.id !== id)
    setEmployees(updated)
    saveEmployees(getEmployeesFromStorage().filter(e => e.id !== id))
  }

  const filteredEmployees = employees.filter(emp =>
    emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.email.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <Layout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
            {t('employees.title')}
          </h1>
          {user?.role === 'admin' && (
            <Button
              onClick={() => navigate('/employees/add')}
              className="flex items-center space-x-2"
            >
              <Plus size={20} />
              <span>Add Employee</span>
            </Button>
          )}
        </div>

        <Card className="mb-6">
          <div className="relative">
            <input
              type="text"
              placeholder={t('common.search')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
            />
          </div>
        </Card>

        {filteredEmployees.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEmployees.map(employee => (
              <Card key={employee.id}>
                <div className="flex items-start justify-between mb-4">
                  <span className="text-4xl">{employee.avatar}</span>
                  <span className="text-xs bg-primary-100 text-primary-800 px-2 py-1 rounded-full dark:bg-primary-900 dark:text-primary-100">
                    {employee.role === 'asset_manager' ? 'Manager' : 'User'}
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
                  {employee.name}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  {employee.department}
                </p>
                <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1 mb-4">
                  <p>Email: {employee.email}</p>
                  <p>Username: {employee.username}</p>
                </div>
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex gap-2">
                    <Button
                      onClick={() => navigate(`/employees/edit/${employee.id}`)}
                      variant="outline"
                      size="sm"
                      className="flex-1 px-3 py-2 border-2 border-primary-600 text-primary-600 rounded-lg flex items-center space-x-2 justify-center"
                    >
                      <Edit size={16} />
                      <span className="text-sm font-medium">Edit</span>
                    </Button>
                    {user?.role === 'admin' && (
                      <button
                        onClick={() => handleDelete(employee.id)}
                        className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg py-2 flex items-center justify-center gap-2"
                      >
                        <Trash2 size={16} />
                        <span className="text-sm font-medium">Delete</span>
                      </button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-400">{t('common.noData')}</p>
          </Card>
        )}
      </div>
    </Layout>
  )
}

export const AddEditEmployee = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const { t } = useTranslation()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    username: '',
    role: 'user',
    department: '',
    password: 'password123',
    avatar: '👤',
  })
  const [errors, setErrors] = useState({})

  const isEditMode = !!id

  useEffect(() => {
    initializeMockData()
    
    if (isEditMode && id) {
      const employees = getEmployeesFromStorage()
      const emp = employees.find(e => parseInt(e.id) === parseInt(id))
      
      if (emp) {
        setFormData({
          name: emp.name || '',
          email: emp.email || '',
          username: emp.username || '',
          role: emp.role || 'user',
          department: emp.department || '',
          password: emp.password || 'password123',
          avatar: emp.avatar || '👤',
        })
      }
    }
  }, [id, isEditMode])

  const handleSubmit = (e) => {
    e.preventDefault()
    const newErrors = {}

    if (!formData.name.trim()) newErrors.name = 'Name is required'
    if (!formData.email.trim()) newErrors.email = 'Email is required'
    if (!formData.department.trim()) newErrors.department = 'Department is required'

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    const employees = getEmployeesFromStorage()
    
    if (isEditMode) {
      const updated = employees.map(e =>
        e.id === parseInt(id) ? { ...e, ...formData } : e
      )
      saveEmployees(updated)
    } else {
      const newEmployee = {
        ...formData,
        id: Math.max(...employees.map(e => e.id), 0) + 1,
      }
      saveEmployees([...employees, newEmployee])
    }

    navigate('/employees')
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-8">
          {isEditMode ? t('employees.editEmployee') : t('employees.addEmployee')}
        </h1>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label={t('employees.name')}
              name="name"
              value={formData.name}
              onChange={handleChange}
              error={errors.name}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('employees.email')}
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                error={errors.email}
              />
              <Input
                label="Username"
                name="username"
                value={formData.username}
                onChange={handleChange}
              />
            </div>

            <Input
              label={t('employees.department')}
              name="department"
              value={formData.department}
              onChange={handleChange}
              error={errors.department}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {t('employees.role')}
              </label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="user">User</option>
                <option value="asset_manager">Asset Manager</option>
              </select>
            </div>

            <div className="flex gap-3 pt-6">
              <Button type="submit" className="flex-1">
                {isEditMode ? 'Update Employee' : 'Create Employee'}
              </Button>
              <Button
                type="button"
                variant="secondary"
                className="flex-1"
                onClick={() => navigate('/employees')}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </Layout>
  )
}
