import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useTranslation } from 'react-i18next'
import { Layout } from '../../components/layout/Layout'
import { Card, Button, Badge } from '../../components/common'
import { getReportsFromStorage, saveReports, getAssetsFromStorage, getEmployeesFromStorage, initializeMockData } from '../../utils/mockData'
import { Plus, Trash2, Edit2, Calendar, X } from 'lucide-react'

export const Reports = () => {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { t } = useTranslation()
  const [reports, setReports] = useState([])
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedReport, setSelectedReport] = useState(null)
  const [editFormData, setEditFormData] = useState({})
  const [assets, setAssets] = useState([])
  const [employees, setEmployees] = useState([])

  useEffect(() => {
    initializeMockData()
    const allReports = getReportsFromStorage()
    const assetsData = getAssetsFromStorage()
    const employeesData = getEmployeesFromStorage()
    
    setAssets(assetsData)
    setEmployees(employeesData)
    
    // Regular users only see their own reports
    if (user?.role === 'user') {
      setReports(allReports.filter(r => r.userId === user.id))
    } else {
      setReports(allReports)
    }
  }, [user])

  const handleDelete = (id) => {
    const updated = reports.filter(r => r.id !== id)
    setReports(updated)
    saveReports(getReportsFromStorage().filter(r => r.id !== id))
  }

  const handleEdit = (report) => {
    setSelectedReport(report)
    setEditFormData(report)
    setShowEditModal(true)
  }

  const handleSaveEdit = () => {
    const selectedAsset = assets.find(a => a.id === parseInt(editFormData.assetId))
    const selectedEmployee = employees.find(e => e.id === parseInt(editFormData.assignedToId))
    
    const updatedReport = {
      ...editFormData,
      assetName: selectedAsset ? selectedAsset.name : editFormData.assetName,
      assignedToName: selectedEmployee ? selectedEmployee.name : editFormData.assignedToName,
    }
    
    const allReports = getReportsFromStorage()
    const updated = allReports.map(r => r.id === selectedReport.id ? updatedReport : r)
    saveReports(updated)
    
    setReports(updated)
    setShowEditModal(false)
  }

  const handleEditChange = (e) => {
    const { name, value } = e.target
    setEditFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const getStatusColor = (status) => {
    switch(status) {
      case 'pending': return 'bg-accent-100 text-accent-800'
      case 'in_progress': return 'bg-blue-100 text-blue-800'
      case 'completed': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <Layout>
      <div className="p-6 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
            {t('reports.title')}
          </h1>
          <Button
            onClick={() => navigate('/reports/add')}
            className="flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>{t('reports.addReport')}</span>
          </Button>
        </div>

        {reports.length > 0 ? (
          <div className="space-y-4">
            {reports.map(report => (
              <Card key={report.id} className="flex items-start justify-between p-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                      {report.title}
                    </h3>
                    <Badge variant={report.status}>{report.status}</Badge>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 mb-2">{report.description}</p>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <span>Author: {report.authorName}</span>
                    {report.assetName && <span>Asset: {report.assetName}</span>}
                    <div className="flex items-center gap-1">
                      <Calendar size={14} />
                      {new Date(report.time).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(report)}
                    className="text-blue-600 hover:text-blue-700 p-2"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={() => handleDelete(report.id)}
                    className="text-red-600 hover:text-red-700 p-2"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-400">{t('common.noData')}</p>
          </Card>
        )}

        {/* Edit Modal */}
        {showEditModal && selectedReport && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-md">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Edit Report</h2>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
                >
                  <X size={24} />
                </button>
              </div>

              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Title
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={editFormData.title || ''}
                    onChange={handleEditChange}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={editFormData.description || ''}
                    onChange={handleEditChange}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100 h-20"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Asset
                  </label>
                  <select
                    name="assetId"
                    value={editFormData.assetId || ''}
                    onChange={handleEditChange}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                  >
                    <option value="">Select an asset</option>
                    {assets.map(asset => (
                      <option key={asset.id} value={asset.id}>{asset.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Assigned To
                  </label>
                  <select
                    name="assignedToId"
                    value={editFormData.assignedToId || ''}
                    onChange={handleEditChange}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                  >
                    <option value="">Select a user</option>
                    {employees.map(emp => (
                      <option key={emp.id} value={emp.id}>{emp.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Status
                  </label>
                  <select
                    name="status"
                    value={editFormData.status || 'pending'}
                    onChange={handleEditChange}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                  >
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    onClick={handleSaveEdit}
                    className="flex-1"
                  >
                    Save Changes
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    className="flex-1"
                    onClick={() => setShowEditModal(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          </div>
        )}
      </div>
    </Layout>
  )
}

export const AddReport = () => {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { t } = useTranslation()
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    assetId: '',
    assignedToId: '',
    status: 'pending',
  })
  const [assets, setAssets] = useState([])
  const [employees, setEmployees] = useState([])

  useEffect(() => {
    initializeMockData()
    const loadedAssets = getAssetsFromStorage()
    const loadedEmployees = getEmployeesFromStorage()
    setAssets(loadedAssets || [])
    setEmployees(loadedEmployees || [])
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    const reports = getReportsFromStorage()
    const selectedAsset = formData.assetId ? assets.find((asset) => String(asset.id) === String(formData.assetId)) : null
    const selectedEmployee = formData.assignedToId ? employees.find((emp) => String(emp.id) === String(formData.assignedToId)) : null
    
    const newReport = {
      id: Math.max(...reports.map((r) => r.id), 0) + 1,
      title: formData.title,
      description: formData.description,
      authorName: user.username || user.name,
      assetId: formData.assetId || null,
      assetName: selectedAsset ? selectedAsset.name : null,
      assignedToId: formData.assignedToId || null,
      assignedToName: selectedEmployee ? selectedEmployee.name : null,
      status: formData.status,
      time: new Date().toISOString(),
    }
    saveReports([...reports, newReport])
    navigate('/reports')
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-8">
          {t('reports.addReport')}
        </h1>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Title
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100 h-20"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Asset
              </label>
              <select
                name="assetId"
                value={formData.assetId}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="">Select an asset</option>
                {assets.map(asset => (
                  <option key={asset.id} value={asset.id}>{asset.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Assigned To
              </label>
              <select
                name="assignedToId"
                value={formData.assignedToId}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="">Select a user</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>{emp.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Status
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" className="flex-1">
                Create Report
              </Button>
              <Button
                type="button"
                variant="secondary"
                className="flex-1"
                onClick={() => navigate('/reports')}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </Layout>
  )
}
