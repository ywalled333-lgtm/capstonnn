import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { Layout } from '../../components/layout/Layout'
import { Card, Button, Input } from '../../components/common'
import { getAssetsFromStorage, saveAssets, getEmployeesFromStorage } from '../../utils/mockData'
import { useAuth } from '../../context/AuthContext'

export const AddEditAsset = () => {
  const navigate = useNavigate()
  const { id } = useParams()
  const { t } = useTranslation()
  const { user } = useAuth()

  // Redirect non-admin/non-asset_manager users
  if (user && user.role === 'user') {
    return (
      <Layout>
        <div className="p-6 max-w-2xl mx-auto">
          <Card className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              Access Denied
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Only administrators and asset managers can add or edit assets.
            </p>
            <Button onClick={() => navigate('/assets')} className="px-6">
              Back to Assets
            </Button>
          </Card>
        </div>
      </Layout>
    )
  }
  const [formData, setFormData] = useState({
    name: '',
    category: 'Electronics',
    type: '',
    price: '',
    location: '',
    status: 'available',
    color: '',
    image: '📦',
    assignedToId: null,
    assignedToName: null,
    date: new Date().toISOString().split('T')[0],
  })
  const [errors, setErrors] = useState({})

  // Filter employees to exclude logged-in user
  const employees = getEmployeesFromStorage().filter(emp => emp.id !== user?.id)
  const isEditMode = !!id

  useEffect(() => {
    if (isEditMode) {
      const assets = getAssetsFromStorage()
      const asset = assets.find(a => a.id === parseInt(id))
      if (asset) {
        setFormData({
          name: asset.name || '',
          category: asset.category || 'Electronics',
          type: asset.type || '',
          price: asset.price || '',
          location: asset.location || '',
          status: asset.status || 'available',
          color: asset.color || '',
          image: asset.image || '📦',
          assignedToId: asset.assignedToId || null,
          assignedToName: asset.assignedToName || null,
          date: asset.date || new Date().toISOString().split('T')[0],
        })
      }
    }
  }, [id, isEditMode])

  const categories = [
    'Electronics',
    'Photography',
    'Mobile',
    'Furniture',
    'Accessories',
    'Other'
  ]

  const statuses = [
    { value: 'available', label: 'Available' },
    { value: 'in_use', label: 'In Use' },
    { value: 'maintenance', label: 'Maintenance' },
    { value: 'retired', label: 'Retired' },
  ]

  const handleSubmit = (e) => {
    e.preventDefault()
    const newErrors = {}

    if (!formData.name.trim()) newErrors.name = 'Asset name is required'
    if (!formData.price) newErrors.price = 'Price is required'
    if (!formData.location.trim()) newErrors.location = 'Location is required'

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    const assets = getAssetsFromStorage()
    if (isEditMode) {
      const updated = assets.map(a =>
        a.id === parseInt(id) ? { ...a, ...formData } : a
      )
      saveAssets(updated)
    }
    navigate('/assets')
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }))
    }
  }

  const handleAssigneeChange = (e) => {
    const selectedId = parseInt(e.target.value)
    const employee = employees.find(emp => emp.id === selectedId)
    setFormData(prev => ({
      ...prev,
      assignedToId: selectedId || null,
      assignedToName: employee?.name || null,
    }))
  }

  return (
    <Layout>
      <div className="p-6 max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-8">
          {isEditMode ? t('assets.editAsset') : t('assets.addAsset')}
        </h1>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('assets.name')}
                name="name"
                value={formData.name}
                onChange={handleChange}
                error={errors.name}
              />
              <Input
                label={t('assets.type')}
                name="type"
                value={formData.type}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('assets.category')}
                </label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-gray-100"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <Input
                label={t('assets.price')}
                name="price"
                type="number"
                value={formData.price}
                onChange={handleChange}
                error={errors.price}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('assets.location')}
                name="location"
                value={formData.location}
                onChange={handleChange}
                error={errors.location}
              />
              <Input
                label={t('assets.color')}
                name="color"
                value={formData.color}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('assets.status')}
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  disabled={user?.role === 'user'}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {statuses.map(status => (
                    <option key={status.value} value={status.value}>
                      {status.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('assets.assignedTo')}
                </label>
                <select
                  value={formData.assignedToId || ''}
                  onChange={handleAssigneeChange}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-gray-100"
                >
                  <option value="">Not assigned</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <Input
              label={t('assets.date')}
              name="date"
              type="date"
              value={formData.date}
              onChange={handleChange}
            />

            <div className="flex gap-3 pt-6">
              <Button
                type="submit"
                className="flex-1"
              >
                Update Asset
              </Button>
              <Button
                type="button"
                variant="secondary"
                className="flex-1"
                onClick={() => navigate('/assets')}
              >
                {t('common.cancel')}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </Layout>
  )
}
