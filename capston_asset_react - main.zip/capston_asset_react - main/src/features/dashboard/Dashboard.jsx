import { useEffect, useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { useTranslation } from 'react-i18next'
import { Card, Badge } from '../../components/common'
import { Layout } from '../../components/layout/Layout'
import { getTasksFromStorage, getAssetsFromStorage, getEmployeesFromStorage, saveAssets } from '../../utils/mockData'
import { BarChart3, Users, Package, CheckCircle, AlertCircle } from 'lucide-react'

const StatCard = ({ icon: Icon, label, value, bgColor, borderColor }) => {
  return (
    <Card className={`border-l-4 ${borderColor}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">{label}</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-gray-100">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${bgColor}`}>
          <Icon size={24} className="text-white" />
        </div>
      </div>
    </Card>
  )
}

const TaskItem = ({ task }) => {
  const statusColors = {
    pending: 'bg-accent-100 text-accent-800',
    in_progress: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
  }

  const priorityColors = {
    high: 'text-red-600',
    medium: 'text-yellow-600',
    low: 'text-green-600',
  }

  return (
    <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-2">
        <h4 className="font-medium text-gray-900 dark:text-gray-100 flex-1">{task.title}</h4>
        <Badge variant={task.status}>{task.status}</Badge>
      </div>
      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{task.description}</p>
      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
        <span>Assigned to: {task.assignedTo}</span>
        <span className={`font-semibold ${priorityColors[task.priority]}`}>
          {task.priority.toUpperCase()}
        </span>
      </div>
    </div>
  )
}

export const Dashboard = () => {
  const { user } = useAuth()
  const { t } = useTranslation()
  const [tasks, setTasks] = useState([])
  const [assets, setAssets] = useState([])
  const [employees, setEmployees] = useState([])
  const [selectedAsset, setSelectedAsset] = useState(null)
  const [showAssetModal, setShowAssetModal] = useState(false)
  const [editedStatus, setEditedStatus] = useState(null)

  useEffect(() => {
    initializeDashboardData()
  }, [])

  const initializeDashboardData = () => {
    setTasks(getTasksFromStorage())
    setAssets(getAssetsFromStorage())
    setEmployees(getEmployeesFromStorage())
  }

  const handleSaveAsset = () => {
    if (!editedStatus || !selectedAsset) return

    // Update the asset status and remove assignment
    const updatedAssets = assets.map(asset => {
      if (asset.id === selectedAsset.id) {
        return {
          ...asset,
          status: editedStatus,
          assignedToId: null,
          assignedToName: null
        }
      }
      return asset
    })

    // Save to storage
    saveAssets(updatedAssets)
    setAssets(updatedAssets)

    // Close modal and reset
    setShowAssetModal(false)
    setSelectedAsset(null)
    setEditedStatus(null)
  }

  const handleOpenAssetModal = (asset) => {
    setSelectedAsset(asset)
    setEditedStatus(asset.status)
    setShowAssetModal(true)
  }

  // Filter tasks for regular users (only assigned to them)
  const userTasks = user?.role === 'user'
    ? tasks.filter(t => t.assignedTo === user?.name)
    : tasks

  // Filter user's assets
  const userAssets = user?.role === 'user'
    ? assets.filter(a => a.assignedToId === user?.id)
    : assets

  return (
    <Layout>
      <div className="p-6 max-w-7xl mx-auto">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            {t('dashboard.welcome')}, {user?.name}! 👋
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {new Date().toLocaleDateString('en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </p>
        </div>

        {/* Statistics Section */}
        {user?.role !== 'user' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              icon={Users}
              label={t('dashboard.totalUsers')}
              value={employees.length}
              bgColor="bg-primary-600"
              borderColor="border-primary-600"
            />
            <StatCard
              icon={Package}
              label={t('dashboard.totalAssets')}
              value={assets.length}
              bgColor="bg-accent-500"
              borderColor="border-accent-500"
            />
            <StatCard
              icon={CheckCircle}
              label="Active Assets"
              value={assets.filter(a => a.status === 'in_use').length}
              bgColor="bg-green-600"
              borderColor="border-green-600"
            />
            <StatCard
              icon={AlertCircle}
              label="Maintenance"
              value={assets.filter(a => a.status === 'maintenance').length}
              bgColor="bg-yellow-600"
              borderColor="border-yellow-600"
            />
          </div>
        )}

        {/* User Assets Section */}
        {user?.role === 'user' && userAssets.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              My Assets
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {userAssets.map(asset => (
                <Card 
                  key={asset.id}
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => handleOpenAssetModal(asset)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <span className="text-3xl">{asset.image}</span>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                          {asset.name}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {asset.category}
                        </p>
                      </div>
                    </div>
                    <Badge variant={asset.status}>{asset.status}</Badge>
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <p>Location: {asset.location}</p>
                    <p>Price: ${asset.price}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Tasks Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              {t('dashboard.tasks')}
            </h2>
            {userTasks.length > 0 ? (
              <div className="space-y-4">
                {userTasks.slice(0, 5).map(task => (
                  <TaskItem key={task.id} task={task} />
                ))}
              </div>
            ) : (
              <Card>
                <p className="text-center text-gray-500 dark:text-gray-400 py-8">
                  No tasks assigned
                </p>
              </Card>
            )}
          </div>

          {/* Tasks Summary */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">
              Task Summary
            </h3>
            <div className="space-y-3">
              <Card>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 dark:text-gray-400">Total Tasks</span>
                  <span className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                    {userTasks.length}
                  </span>
                </div>
              </Card>
              <Card>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 dark:text-gray-400">In Progress</span>
                  <span className="text-2xl font-bold text-blue-600">
                    {userTasks.filter(t => t.status === 'in_progress').length}
                  </span>
                </div>
              </Card>
              <Card>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 dark:text-gray-400">Completed</span>
                  <span className="text-2xl font-bold text-green-600">
                    {userTasks.filter(t => t.status === 'completed').length}
                  </span>
                </div>
              </Card>
              <Card>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 dark:text-gray-400">Pending</span>
                  <span className="text-2xl font-bold text-accent-500">
                    {userTasks.filter(t => t.status === 'pending').length}
                  </span>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Asset Details Modal */}
      {showAssetModal && selectedAsset && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <span className="text-5xl">{selectedAsset.image}</span>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                    {selectedAsset.name}
                  </h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {selectedAsset.category} • {selectedAsset.type}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Asset ID</p>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{selectedAsset.id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Serial Number</p>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{selectedAsset.serialNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Price</p>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">${selectedAsset.price}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Status</p>
                  <select
                    value={editedStatus}
                    onChange={(e) => setEditedStatus(e.target.value)}
                    className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-primary-500 focus:ring-primary-500 dark:bg-gray-700 dark:text-gray-100 font-semibold"
                  >
                    <option value="in_use">In Use</option>
                    <option value="retired">Retired</option>
                  </select>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Location</p>
                <p className="font-semibold text-gray-900 dark:text-gray-100">{selectedAsset.location}</p>
              </div>

              {selectedAsset.description && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Description</p>
                  <p className="text-gray-900 dark:text-gray-100">{selectedAsset.description}</p>
                </div>
              )}

              {selectedAsset.assignedToName && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Assigned To</p>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{selectedAsset.assignedToName}</p>
                </div>
              )}

              {selectedAsset.purchaseDate && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Purchase Date</p>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{new Date(selectedAsset.purchaseDate).toLocaleDateString()}</p>
                </div>
              )}

              <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700 rounded-lg p-3 mt-4">
                <p className="text-sm text-blue-800 dark:text-blue-100">
                  <strong>Note:</strong> When you save, this asset will be returned and removed from your assigned items.
                </p>
              </div>
            </div>

            <div className="flex gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => {
                  setShowAssetModal(false)
                  setSelectedAsset(null)
                  setEditedStatus(null)
                }}
                className="flex-1 px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveAsset}
                className="flex-1 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition-colors font-medium"
              >
                Save Changes
              </button>
            </div>
          </Card>
        </div>
      )}
    </Layout>
  )
}
